const gulp = require('gulp');
const cleanCSS = require('gulp-clean-css');
const uglify = require('gulp-uglify');
const imagemin = require('gulp-imagemin');
const concat = require('gulp-concat');
const rename = require('gulp-rename');
const browserSync = require('browser-sync').create();
const autoprefixer = require('gulp-autoprefixer');
const sourcemaps = require('gulp-sourcemaps');
const fileinclude = require('gulp-file-include');

// 경로 설정
const paths = {
  html: {
    src: [
      'project/src/*.html',
      'project/src/pages/**/*.html',
      '!project/src/layouts/**',
      '!project/src/partials/**',
      '!project/src/components/**/*.html'
    ],
    dest: 'project/dest/',
    watch: ['project/src/**/*.html']
  },
  styles: {
    src: 'project/src/css/**/*.css',
    dest: 'project/dest/css/'
  },
  scripts: {
    src: 'project/src/js/**/*.js',
    dest: 'project/dest/js/'
  },
  images: {
    src: 'project/src/images/**/*',
    dest: 'project/dest/images/'
  },
  fonts: {
    src: 'project/src/fonts/**/*',
    dest: 'project/dest/fonts/'
  }
};

// HTML 처리 (파일 include)
function html() {
  return gulp.src(paths.html.src, { base: 'project/src' })
    .pipe(fileinclude({
      prefix: '@@',
      basepath: 'project/src/'
    }))
    .pipe(gulp.dest(paths.html.dest))
    .pipe(browserSync.stream());
}

// CSS 처리 (Autoprefixer 적용)
function styles() {
  return gulp.src(paths.styles.src)
    .pipe(sourcemaps.init())
    .pipe(autoprefixer({
      cascade: false
    }))
    .pipe(sourcemaps.write('.'))
    .pipe(gulp.dest(paths.styles.dest))
    .pipe(browserSync.stream());
}

// CSS 압축 (배포용)
function minifyStyles() {
  return gulp.src(paths.styles.dest + '*.css')
    .pipe(cleanCSS())
    .pipe(rename({ suffix: '.min' }))
    .pipe(gulp.dest(paths.styles.dest));
}

// JavaScript 번들링
function scripts() {
  return gulp.src(paths.scripts.src)
    .pipe(sourcemaps.init())
    .pipe(concat('main.js'))
    .pipe(sourcemaps.write('.'))
    .pipe(gulp.dest(paths.scripts.dest))
    .pipe(browserSync.stream());
}

// JavaScript 압축 (배포용)
function minifyScripts() {
  return gulp.src(paths.scripts.dest + 'main.js')
    .pipe(uglify())
    .pipe(rename({ suffix: '.min' }))
    .pipe(gulp.dest(paths.scripts.dest));
}

// 이미지 최적화
function images() {
  return gulp.src(paths.images.src)
    .pipe(imagemin([
      imagemin.gifsicle({ interlaced: true }),
      imagemin.mozjpeg({ quality: 80, progressive: true }),
      imagemin.optipng({ optimizationLevel: 5 }),
      imagemin.svgo({
        plugins: [
          { removeViewBox: false },
          { cleanupIDs: false }
        ]
      })
    ]))
    .pipe(gulp.dest(paths.images.dest));
}

// 폰트 복사
function fonts() {
  return gulp.src(paths.fonts.src)
    .pipe(gulp.dest(paths.fonts.dest));
}

// 파일 감시
function watch() {
  browserSync.init({
    server: {
      baseDir: './project/dest'
    },
    port: 3000,
    ghostMode: false,
    open: true
  });

  gulp.watch(paths.html.watch, html);
  gulp.watch(paths.styles.src, styles);
  gulp.watch(paths.scripts.src, scripts);
  gulp.watch(paths.images.src, images);
}

// Clean 태스크
function clean() {
  const del = require('del');
  return del(['project/dest/**/*', '!project/dest']);
}

// 태스크 내보내기
exports.html = html;
exports.styles = styles;
exports.scripts = scripts;
exports.images = images;
exports.fonts = fonts;
exports.watch = watch;
exports.clean = clean;

// 개발 모드
exports.dev = gulp.series(
  gulp.parallel(html, styles, scripts),
  watch
);

// 빌드 (배포용)
exports.build = gulp.series(
  clean,
  gulp.parallel(html, styles, scripts, images, fonts),
  gulp.parallel(minifyStyles, minifyScripts)
);

// 기본 태스크
exports.default = exports.dev;

