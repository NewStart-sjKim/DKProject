// 메인 JavaScript 파일
// 이 파일은 Gulp에 의해 번들링되고 압축됩니다

console.log('웹사이트가 로드되었습니다!');

// DOM이 준비되면 실행
document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM이 준비되었습니다.');

  // 버튼 클릭 이벤트 예제
  const buttons = document.querySelectorAll('.button');
  buttons.forEach(button => {
    button.addEventListener('click', function(e) {
      console.log('버튼이 클릭되었습니다:', e.target);
    });
  });
});

/**
 * 메인 네비게이션 활성화 처리
 * - /pages/status/* 경로: 첫 번째 네비게이션 링크(IA List) 활성화
 * - /pages/wsg/* 경로: 두 번째 네비게이션 링크(Web Style Guide) 활성화
 */
document.addEventListener('DOMContentLoaded', function() {
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.site-header nav a');
  
  console.log('현재 경로:', currentPath);
  
  // 경로를 '/'로 분리하여 배열로 변환
  const pathSegments = currentPath.split('/').filter(segment => segment !== '');
  console.log('경로 세그먼트:', pathSegments);
  
  // 모든 네비게이션 링크의 active 클래스 제거
  navLinks.forEach(link => link.classList.remove('active'));
  
  // 경로가 없거나 index인 경우 첫 번째 링크 활성화
  if (pathSegments.length === 0 || 
      currentPath === '/' || 
      currentPath.includes('index.html')) {
    if (navLinks[0]) {
      navLinks[0].classList.add('active');
    }
    return;
  }
  
  // /pages/ 이후의 첫 번째 세그먼트로 구분
  const pagesIndex = pathSegments.indexOf('pages');
  if (pagesIndex !== -1 && pagesIndex + 1 < pathSegments.length) {
    const section = pathSegments[pagesIndex + 1]; // 'status' 또는 'wsg'
    
    console.log('섹션:', section);
    
    // 섹션에 따라 네비게이션 활성화
    if (section === 'status') {
      // status 섹션 -> 첫 번째 링크 (IA List)
      if (navLinks[0]) {
        navLinks[0].classList.add('active');
      }
    } else if (section === 'wsg') {
      // wsg 섹션 -> 두 번째 링크 (Web Style Guide)
      if (navLinks[1]) {
        navLinks[1].classList.add('active');
      }
    }
  }
});

/**
 * 서브 메뉴 활성화 처리
 * - URL의 마지막 파일명을 기준으로 서브 메뉴 활성화
 * - 예: /pages/wsg/icon.html -> icon.html과 매칭되는 링크 활성화
 */
document.addEventListener('DOMContentLoaded', function() {
  const subMenuLinks = document.querySelectorAll('.sub-menu-link');
  
  // 서브 메뉴가 없는 페이지는 처리하지 않음
  if (subMenuLinks.length === 0) {
    return;
  }
  
  const currentPath = window.location.pathname;
  console.log('서브메뉴 - 현재 경로:', currentPath);
  
  // 경로에서 파일명 추출 (마지막 '/' 이후의 문자열)
  const pathParts = currentPath.split('/');
  const currentFileName = pathParts[pathParts.length - 1] || '';
  
  console.log('현재 파일명:', currentFileName);
  
  // 모든 서브 메뉴 링크의 active 제거
  subMenuLinks.forEach(link => link.classList.remove('active'));
  
  // 각 서브 메뉴 링크를 확인하여 매칭되는 것에 active 추가
  let isActivated = false;
  subMenuLinks.forEach(link => {
    const linkHref = link.getAttribute('href');
    
    // href가 해시(#)인 경우와 파일 경로인 경우 모두 처리
    if (linkHref) {
      // 파일 경로인 경우
      if (linkHref.includes('/')) {
        const linkParts = linkHref.split('/');
        const linkFileName = linkParts[linkParts.length - 1];
        
        // 현재 파일명과 링크의 파일명이 일치하면 active 추가
        if (linkFileName === currentFileName) {
          link.classList.add('active');
          isActivated = true;
          console.log('활성화된 서브메뉴:', linkFileName);
        }
      }
      // 해시 링크인 경우 (향후 확장을 위해)
      else if (linkHref.startsWith('#')) {
        // 해시는 현재 파일에서만 작동하므로 별도 처리 가능
        // 필요시 구현
      }
    }
  });
  
  // 매칭되는 링크가 없으면 첫 번째 링크를 활성화 (기본값)
  if (!isActivated && subMenuLinks.length > 0) {
    subMenuLinks[0].classList.add('active');
    console.log('기본 서브메뉴 활성화');
  }
  
  // 서브 메뉴 클릭 시 active 전환 (페이지 이동이 아닌 해시 이동의 경우)
  subMenuLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      
      // 해시 링크인 경우에만 active 전환 (페이지 이동이 없으므로)
      if (href && href.startsWith('#')) {
        // 모든 서브 메뉴에서 active 제거
        subMenuLinks.forEach(l => l.classList.remove('active'));
        // 클릭한 메뉴에 active 추가
        this.classList.add('active');
      }
      // 파일 경로인 경우는 페이지가 리로드되므로 위의 로직이 다시 실행됨
    });
  });
});

/**
 * TOP 링크 스크롤 기능
 */
document.addEventListener('DOMContentLoaded', function() {
  const topLinks = document.querySelectorAll('.top-link');
  
  topLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  });
});

/**
 * 아이콘 동적 로딩
 * - svgIcon 폴더의 모든 아이콘을 자동으로 불러와 표시
 */
document.addEventListener('DOMContentLoaded', function() {
  // 아이콘 그리드와 SNS 아이콘 컨테이너
  const iconGrid = document.getElementById('iconGrid');
  const snsIcons = document.getElementById('snsIcons');
  
  // 아이콘 페이지가 아니면 실행하지 않음
  if (!iconGrid && !snsIcons) {
    return;
  }
  
  
  const mainNavigationIconList = [
    {'svg':'ic_home.svg','name':'홈'},
    {'svg':'ic_cart.svg','name':'장바구니'},
    {'svg':'ic_calendar.svg','name':'달력'},
    {'svg':'ic_heart.svg','name':'좋아요'},
    {'svg':'ic_my_profile.svg','name':'내 프로필'},
    {'svg':'ic_login.svg','name':'로그인'},
    {'svg':'ic_logout.svg','name':'로그아웃'},
  ]
  
 
  const actionIconList = [
    {'svg':'ic_search.svg', 'name':'검색'},
    {'svg':'ic_notification.svg', 'name':'알림'},
    {'svg':'ic_setting.svg', 'name':'설정'},
    {'svg':'ic_menu.svg', 'name':'메뉴'},
    {'svg':'ic_x.svg', 'name':'닫기'},
    {'svg':'ic_plus.svg', 'name':'플러스'},
    {'svg':'ic_minus.svg', 'name':'마이너스'},
    {'svg':'ic_edit.svg', 'name':'편집'},
    {'svg':'ic_delete.svg', 'name':'삭제'},
    {'svg':'ic_save.svg','name':'저장'},
    
  ]
  
  const fileAndShear = [
    {'svg':'ic_upload.svg', 'name':'업로드'},
    {'svg':'ic_share.svg', 'name':'공유'},
    {'svg':'ic_download.svg', 'name':'다운로드'},
    {'svg':'ic_favorite.svg','name':'즐겨찾기'},
    {'svg':'ic_bookmark.svg','name':'북마크'},
    {'svg':'ic_copy.svg','name':'복사'},
    {'svg':'ic_external_link.svg','name':'외부링크'},
    {'svg':'ic_refresh.svg','name':'새로고침'},
    {'svg':'ic_undo.svg','name':'되돌리다'},
  ]

  const communicationIconList = [
    {'svg':'ic_message.svg','name':'메시지'},
    {'svg':'ic_telephone.svg','name':'전화'},
    {'svg':'ic_email.svg','name':'이메일'},
    {'svg':'ic_mic.svg','name':'마이크'},
    {'svg':'ic_mic_off.svg','name':'마이크끄기'},
    {'svg':'ic_headphone.svg','name':'헤드폰'},
    {'svg':'ic_speaker.svg','name':'스피커'},
  ]

  
  const userAndocialIconList = [
    {'svg':'ic_global.svg','name':'지구본'},
    {'svg':'ic_location.svg','name':'위치'},
    {'svg':'ic_flag.svg','name':'깃발'},
    {'svg':'ic_prize.svg','name':'상'},
    {'svg':'ic_award.svg','name':'어워드드'},
    {'svg':'ic_gift.svg','name':'선물'},
    {'svg':'ic_coffee.svg','name':'커피'},
    {'svg':'ic_tableware.svg','name':'식기'},
    {'svg':'ic_hospital.svg','name':'병원'},
    {'svg':'ic_book.svg','name':'책'},
    {'svg':'ic_newspaper.svg','name':'신문'},
    {'svg':'ic_tv.svg','name':'TV'},
    {'svg':'ic_configuratio.svg','name':'비교'},
  ]


  const businessIconList = [
    {'svg':'ic_rising.svg','name':'상승'},
    {'svg':'ic_biz_down.svg','name':'하락'},
    {'svg':'ic_line_chart.svg','name':'라인차트'},
    {'svg':'ic_bar_chart.svg','name':'막대차트'},
    {'svg':'ic_pi_chart.svg','name':'파이차트'},
    {'svg':'ic_package.svg','name':'패키지'},
  ]


  const ecommerceIconList = [
    {'svg':'ic_creditcard.svg','name':'신용카드'},
    {'svg':'ic_dollar.svg','name':'달러'},
    {'svg':'ic_euro.svg','name':'유로'},
    {'svg':'ic_wallet.svg','name':'지갑'},
    {'svg':'ic_bank.svg','name':'은행'},
    {'svg':'ic_receipt.svg','name':'영수증'},
    {'svg':'ic_delivery.svg','name':'배송'},
    {'svg':'ic_shopping_bag.svg','name':'쇼핑백'},
    {'svg':'ic_shopping_basket.svg','name':'쇼핑바구니'},
    {'svg':'ic_store.svg','name':'상점점'},
    {'svg':'ic_tag.svg','name':'태그'},
    {'svg':'ic_percent.svg','name':'할인'},
    {'svg':'ic_target.svg','name':'타겟'},
    {'svg':'ic_handshake.svg','name':'악수수'},
    {'svg':'ic_building.svg','name':'빌딩딩'},
  ]


  const statusAndInfIconList = [
    {'svg':'ic_delivery_completed.svg','name':'체크'},
    {'svg':'ic_xbox.svg','name':'에러'},
    {'svg':'ic_warning.svg','name':'경고'},
    {'svg':'ic_information.svg','name':'정보'},
    {'svg':'ic_none.svg','name':'정보없음'},
    {'svg':'ic_help.svg','name':'도움말'},
    {'svg':'ic_lock.svg','name':'잠금'},
    {'svg':'ic_view.svg','name':'보기'},
    {'svg':'ic_close_view.svg','name':'닫기'},
    {'svg':'ic_key.svg','name':'비밀번호'},
  ]

  const orderAndInfIconList = [
    {'svg':'ic_order_reception.svg','name':'주문접수'},
    {'svg':'ic_order_confirmed.svg','name':'주문확정'},
    {'svg':'ic_shipment_completed.svg','name':'배송완료'},
    {'svg':'ic_In_transit.svg','name':'배송중'},
    {'svg':'ic_delivery_completed.svg','name':'배송완료'},
  ]

  const directionAndNavIconList = [
    {'svg':'ic_arrow_left.svg','name':'왼쪽화살표'},
    {'svg':'ic_arrow_right.svg','name':'오른쪽화살표'},
    {'svg':'ic_arrow_down.svg','name':'아래화살표'},
    {'svg':'ic_top.svg','name':'위쪽화살표'},
    {'svg':'ic_up_arrow.svg','name':'위쪽펼치기'},
    {'svg':'ic_down_arrow.svg','name':'아래쪽펼치기'},
    {'svg':'ic_left_arrow.svg','name':'왼쪽펼치기'},
    {'svg':'ic_right_arrow.svg','name':'오른쪽펼치기'},
    {'svg':'ic_double_left_arrow.svg','name':'더블왼쪽'},
    {'svg':'ic_double_right_arrow.svg','name':'더블오른쪽'},
    {'svg':'ic_double_up.svg','name':'더블위'},
    {'svg':'ic_double_arrow_down.svg','name':'더블아래'},
  ]

  const implementAndUtileIconList = [
    {'svg':'ic_calculator.svg','name':'계산기'},
    {'svg':'ic_clock.svg','name':'시계'},
    {'svg':'ic_timer.svg','name':'타이머'},
    {'svg':'ic_alarm.svg','name':'알람'},
    {'svg':'ic_thermometer.svg','name':'온도계'},
    {'svg':'ic_umbrella.svg','name':'우산'},
    {'svg':'ic_bulb.svg','name':'전구'},
    {'svg':'ic_brain.svg','name':'뇌'},
    {'svg':'ic_puzzle.svg','name':'퍼즐'},
    {'svg':'ic_sort.svg','name':'정렬'},
  ]

  const weatherIconList = [
    {'svg':'ic_sunset.svg','name':'일출'},
    {'svg':'ic_sunrise.svg','name':'일몰'},
    {'svg':'ic_snow.svg','name':'눈'},
    {'svg':'ic_rain.svg','name':'비'},
    {'svg':'ic_sunny.svg','name':'맑음'},
    {'svg':'ic_lightning.svg','name':'번개'},
    {'svg':'ic_umbrella.svg','name':'우산'},
    {'svg':'ic_moon.svg','name':'달'},
    {'svg':'ic_cloud.svg','name':'구름'},
  ]

  const mediaIconList = [
    {'svg':'ic_camera.svg','name':'카메라'},
    {'svg':'ic_image.svg','name':'이미지'},
    {'svg':'ic_video.svg','name':'비디오'},
    {'svg':'ic_music.svg','name':'음악'},
    {'svg':'ic_play.svg','name':'재생'},
    {'svg':'ic_pause.svg','name':'일시정지'},
    {'svg':'ic_before.svg','name':'이전'},
    {'svg':'ic_next.svg','name':'다음'},
    {'svg':'ic_volume.svg','name':'볼륨'},
    {'svg':'ic_mute.svg','name':'음소거'},
  ]

  const documentAndWork = [
    {'svg':'ic_document.svg','name':'문서'},
    {'svg':'ic_folder.svg','name':'폴더'},
    {'svg':'ic_clipboard.svg','name':'클립보드'},
    {'svg':'ic_presentation.svg','name':'프리젠테이션'},
    {'svg':'ic_briefcase.svg','name':'서류가방'},
    {'svg':'ic_printer.svg','name':'프린터'},
    {'svg':'ic_spreadsheet.svg','name':'스프레드시트'},
    {'svg':'ic_monitor.svg','name':'모니터'},
    {'svg':'ic_notebook.svg','name':'노트북'},
    {'svg':'ic_tablet.svg','name':'태블릿'},
    {'svg':'ic_folder_add.svg','name':'폴더추가'},
    {'svg':'ic_file_add.svg','name':'파일추가'},
    {'svg':'ic_filecheck.svg','name':'파일체크'},
    {'svg':'ic_schedule_check.svg','name':'일정체크'},
    {'svg':'ic_schedule_add.svg','name':'일정추가'},
  ]

  const financeAndAccounting = [
    {'svg':'ic_pigbank.svg','name':'돼지저금통'},
    {'svg':'ic_locker.svg','name':'보관함'},
    {'svg':'ic_activity.svg','name':'활동'},
    {'svg':'ic_gauge.svg','name':'게이지'},
    {'svg':'ic_security.svg','name':'보안'},
    {'svg':'ic_security_check.svg','name':'보안체크'},
    {'svg':'ic_database.svg','name':'데이터베이스'},
    {'svg':'ic_server.svg','name':'서버'},
    {'svg':'ic_storage_d.svg','name':'저장장치'},
    {'svg':'ic_storage_device.svg','name':'클라우드'},
    {'svg':'ic_network.svg','name':'네트워크'},
    {'svg':'ic_medal.svg','name':'메달'},
  ]

  const meetingAndCooperation = [
    {'svg':'ic_users.svg','name':'사용자들'},
    {'svg':'ic_user_add.svg','name':'사용자추가'},
    {'svg':'ic_user_delete.svg','name':'사용자제거'},
    {'svg':'ic_user_check.svg','name':'사용자체크'},
    {'svg':'ic_user_cancel.svg','name':'사용자취소'},
    {'svg':'ic_megaphone.svg','name':'메가폰'},
    {'svg':'ic_workflow.svg','name':'워크플로우'},
    {'svg':'ic_git_branch.svg','name':'깃브랜치'},
    {'svg':'ic_git_commit.svg','name':'깃커밋'},
    {'svg':'ic_git_merge.svg','name':'깃병합'},
    {'svg':'ic_full_request.svg','name':'플리퀘스트트'},
    {'svg':'ic_layer.svg','name':'레이어'},
    {'svg':'ic_component.svg','name':'컴포넌트'},
    {'svg':'ic_link.svg','name':'링크'},
    {'svg':'ic_unlink.svg','name':'링크해제'},
    {'svg':'ic_zoom_in.svg','name':'확대'},
    {'svg':'ic_zoom_out.svg','name':'축소'},
  ]
    //{'svg':'ic_','name':''},
  // 아이콘 베이스 경로
  const iconBasePath = '../../images/svgIcon/';
  
  const snsIconList = [
    {'svg':'ic_facebook.svg','name':'페이스북'},
    {'svg':'ic_instagram.svg','name':'인스타그램'},
    {'svg':'ic_twitter.svg','name':'트위터'},
    {'svg':'ic_youtube.svg','name':'유튜브'},
    {'svg':'ic_linkedin.svg','name':'링크드인'},
    {'svg':'ic_pinterest.svg','name':'핀터레스트'},
    {'svg':'ic_tiktok.svg','name':'틱톡'},
    {'svg':'ic_snapchat.svg','name':'스냅챗'},
  ]

  /**
   * 아이콘 아이템 생성 함수
   * @param {Object} iconObj - 아이콘 객체 {svg: '파일명', name: '이름'}
   * @returns {HTMLElement} - 생성된 아이콘 아이템 요소
   */
  function createIconItem(iconObj) {
    const iconItem = document.createElement('div');
    iconItem.className = 'icon-item';
    
    const iconImg = document.createElement('div');
    iconImg.className = 'icon-img';
    iconImg.style.backgroundImage = `url('${iconBasePath}${iconObj.svg}')`;
    
    const iconName = document.createElement('div');
    iconName.className = 'icon-name';
    iconName.textContent = iconObj.name;
    
    iconItem.appendChild(iconImg);
    iconItem.appendChild(iconName);
    
    // 클릭 시 정보 콘솔 출력 (개발용)
    iconItem.addEventListener('click', function() {
      console.log('아이콘 클릭:', iconObj);
    });
    
    return iconItem;
  }

  /**
   * 아이콘 섹션 생성 함수
   * @param {string} title - 섹션 제목
   * @param {Array} iconList - 아이콘 객체 배열
   * @returns {HTMLElement} - 생성된 섹션 요소
   */
  function createIconSection(title, iconList) {
    const section = document.createElement('div');
    section.className = 'icon-section';
    
    const sectionTitle = document.createElement('h3');
    sectionTitle.className = 'icon-section-title';
    sectionTitle.textContent = title;
    
    const grid = document.createElement('div');
    grid.className = 'icon-grid';
    
    iconList.forEach(iconObj => {
      const iconItem = createIconItem(iconObj);
      grid.appendChild(iconItem);
    });
    
    section.appendChild(sectionTitle);
    section.appendChild(grid);
    
    return section;
  }
  
  // 메인 아이콘 그리드에 아이콘 섹션 추가
  if (iconGrid) {
    const iconSections = [
      { title: 'Main Navigation', list: mainNavigationIconList },
      { title: 'Action', list: actionIconList },
      { title: 'File & Share', list: fileAndShear },
      { title: 'Communication', list: communicationIconList },
      { title: 'User & Social', list: userAndocialIconList },
      { title: 'Business', list: businessIconList },
      { title: 'E-commerce', list: ecommerceIconList },
      { title: 'Status & Info', list: statusAndInfIconList },
      { title: 'Order & Info', list: orderAndInfIconList },
      { title: 'Direction & Navigation', list: directionAndNavIconList },
      { title: 'Tools & Utilities', list: implementAndUtileIconList },
      { title: 'Weather', list: weatherIconList },
      { title: 'Media', list: mediaIconList },
      { title: 'Document & Work', list: documentAndWork },
      { title: 'Finance & Accounting', list: financeAndAccounting },
      { title: 'Meeting & Cooperation', list: meetingAndCooperation },
    ];
    
    iconSections.forEach(section => {
      const sectionElement = createIconSection(section.title, section.list);
      iconGrid.appendChild(sectionElement);
    });
    
    const totalIcons = iconSections.reduce((sum, section) => sum + section.list.length, 0);
    console.log(`총 ${totalIcons}개의 아이콘이 로드되었습니다.`);
  }
  
  // // SNS 아이콘 영역에 아이콘 추가
  // if (snsIcons) {
  //   snsIconList.forEach(iconObj => {
  //     const iconItem = createIconItem(iconObj);
  //     snsIcons.appendChild(iconItem);
  //   });
    
  //   console.log(`총 ${snsIconList.length}개의 SNS 아이콘이 로드되었습니다.`);
  // }
});

/**
 * Custom Select Box 기능
 * - 옵션에 호버 효과 적용 가능
 */
document.addEventListener('DOMContentLoaded', function() {
  const customSelects = document.querySelectorAll('.custom-select-wrapper');
  
  customSelects.forEach(selectWrapper => {
    const display = selectWrapper.querySelector('.custom-select-display');
    const dropdown = selectWrapper.querySelector('.custom-select-dropdown');
    const options = selectWrapper.querySelectorAll('.custom-select-option');
    
    // Display 클릭 시 드롭다운 토글
    display.addEventListener('click', function(e) {
      e.stopPropagation();
      
      // 다른 열려있는 select box 닫기
      document.querySelectorAll('.custom-select-wrapper.open').forEach(openSelect => {
        if (openSelect !== selectWrapper) {
          openSelect.classList.remove('open');
        }
      });
      
      selectWrapper.classList.toggle('open');
    });
    
    // 옵션 선택
    options.forEach(option => {
      option.addEventListener('click', function(e) {
        e.stopPropagation();
        
        const value = this.getAttribute('data-value');
        const text = this.textContent;
        
        // 선택된 옵션 표시
        display.textContent = text;
        display.classList.remove('placeholder');
        
        // 선택 상태 업데이트
        options.forEach(opt => opt.classList.remove('selected'));
        this.classList.add('selected');
        
        // 드롭다운 닫기
        selectWrapper.classList.remove('open');
        
        console.log('선택된 값:', value, text);
      });
    });
  });
  
  // 외부 클릭 시 모든 드롭다운 닫기
  document.addEventListener('click', function() {
    document.querySelectorAll('.custom-select-wrapper.open').forEach(openSelect => {
      openSelect.classList.remove('open');
    });
  });
});

/**
 * Multiselect 드롭다운 토글 기능
 * - 토글 버튼 클릭 시 드롭다운 열기/닫기
 */
document.addEventListener('DOMContentLoaded', function() {
  const multiselectWrappers = document.querySelectorAll('.form-multiselect-wrapper');
  
  multiselectWrappers.forEach(wrapper => {
    const toggleBtn = wrapper.querySelector('.form-multiselect-toggle');
    const dropdown = wrapper.nextElementSibling;
    
    if (toggleBtn && dropdown && dropdown.classList.contains('form-multiselect-dropdown')) {
      // 토글 버튼 클릭 이벤트
      toggleBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        
        const isOpen = dropdown.classList.contains('on');
        
        // 다른 열려있는 multiselect 닫기
        document.querySelectorAll('.form-multiselect-dropdown.on').forEach(openDropdown => {
          openDropdown.classList.remove('on');
        });
        
        // 모든 화살표 원래대로
        document.querySelectorAll('.form-multiselect-toggle img').forEach(img => {
          img.style.transform = 'rotate(0deg)';
        });
        
        // 현재 드롭다운 토글
        if (!isOpen) {
          dropdown.classList.add('on');
          toggleBtn.querySelector('img').style.transform = 'rotate(180deg)';
        } else {
          dropdown.classList.remove('on');
          toggleBtn.querySelector('img').style.transform = 'rotate(0deg)';
        }
        
        console.log('Multiselect 드롭다운 토글:', !isOpen ? '열림' : '닫힘');
      });
      
      // 체크박스 옵션 클릭 이벤트
      const options = dropdown.querySelectorAll('.multiselect-option');
      options.forEach(option => {
        const checkbox = option.querySelector('input[type="checkbox"]');
        const label = option.querySelector('span');
        
        option.addEventListener('click', function(e) {
          // 체크박스 자체를 클릭한 경우는 기본 동작 유지
          if (e.target === checkbox) {
            return;
          }
          
          // 라벨이나 옵션 영역을 클릭한 경우 체크박스 토글
          e.preventDefault();
          checkbox.checked = !checkbox.checked;
          
          // 선택된 항목들 업데이트
          updateMultiselectDisplay(wrapper, dropdown);
          
          console.log('옵션 선택:', label.textContent, checkbox.checked);
        });
        
        // 체크박스 직접 클릭 시에도 업데이트
        checkbox.addEventListener('change', function() {
          updateMultiselectDisplay(wrapper, dropdown);
        });
      });
    }
  });
  
  /**
   * Multiselect 표시 영역 업데이트
   */
  function updateMultiselectDisplay(wrapper, dropdown) {
    const display = wrapper.querySelector('.form-multiselect-display');
    const checkedOptions = dropdown.querySelectorAll('input[type="checkbox"]:checked');
    
    // 기존 배지 제거
    display.innerHTML = '';
    
    // 선택된 항목들로 배지 생성
    checkedOptions.forEach(checkbox => {
      const label = checkbox.parentElement.querySelector('span');
      const badge = document.createElement('span');
      badge.className = 'multiselect-badge';
      badge.textContent = label.textContent;
      
      // 배지 클릭 시 해당 항목 제거
      badge.addEventListener('click', function(e) {
        e.stopPropagation();
        checkbox.checked = false;
        updateMultiselectDisplay(wrapper, dropdown);
      });
      
      display.appendChild(badge);
    });
    
    // 선택된 항목이 없으면 placeholder 표시
    if (checkedOptions.length === 0) {
      display.innerHTML = '<span style="color: #999;">옵션을 선택하세요</span>';
    }
  }
  
  // 외부 클릭 시 모든 multiselect 드롭다운 닫기
  document.addEventListener('click', function() {
    document.querySelectorAll('.form-multiselect-dropdown.on').forEach(dropdown => {
      dropdown.classList.remove('on');
    });
  });
});