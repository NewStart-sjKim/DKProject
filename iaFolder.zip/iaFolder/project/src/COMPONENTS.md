# 컴포넌트 사용 가이드

## 📦 컴포넌트 폴더 구조

```
project/src/
├── components/              # 재사용 가능한 컴포넌트
│   ├── hero-section.html   # 히어로 섹션
│   ├── page-list.html      # 페이지 목록
│   ├── card.html           # 카드 (변수 지원)
│   └── button-group.html   # 버튼 그룹 (변수 지원)
├── partials/               # 공통 레이아웃 요소
│   ├── header.html
│   └── footer.html
└── pages/                  # 페이지 파일
```

## 🎯 컴포넌트 사용 방법

### 1️⃣ 기본 사용 (변수 없이)

```html
<!-- index.html -->
<main>
  @@include('components/hero-section.html')
  @@include('components/page-list.html')
</main>
```

### 2️⃣ 변수와 함께 사용

```html
<!-- 카드 컴포넌트 사용 -->
@@include('components/card.html', {
  "title": "카드 제목",
  "description": "카드 설명입니다.",
  "link": "#",
  "buttonText": "자세히 보기"
})

<!-- 버튼 그룹 컴포넌트 사용 -->
@@include('components/button-group.html', {
  "primaryLink": "/download",
  "primaryText": "다운로드",
  "secondaryLink": "/docs",
  "secondaryText": "문서 보기"
})
```

### 3️⃣ 여러 번 재사용

```html
<main>
  <div class="cards-container">
    @@include('components/card.html', {
      "title": "첫 번째 카드",
      "description": "첫 번째 카드 설명",
      "link": "/page1",
      "buttonText": "더보기"
    })
    
    @@include('components/card.html', {
      "title": "두 번째 카드",
      "description": "두 번째 카드 설명",
      "link": "/page2",
      "buttonText": "자세히"
    })
    
    @@include('components/card.html', {
      "title": "세 번째 카드",
      "description": "세 번째 카드 설명",
      "link": "/page3",
      "buttonText": "보기"
    })
  </div>
</main>
```

## ✨ 새 컴포넌트 만들기

### 1단계: 컴포넌트 파일 생성

```html
<!-- components/alert.html -->
<div class="alert alert-@@type">
  <strong>@@title</strong>
  <p>@@message</p>
</div>
```

### 2단계: CSS 스타일 추가

```css
/* style.css */
.alert {
  padding: 1rem;
  border-radius: 4px;
  margin: 1rem 0;
}

.alert-success {
  background-color: #d4edda;
  color: #155724;
}

.alert-warning {
  background-color: #fff3cd;
  color: #856404;
}
```

### 3단계: 사용하기

```html
@@include('components/alert.html', {
  "type": "success",
  "title": "성공!",
  "message": "작업이 완료되었습니다."
})
```

## 🎨 현재 사용 가능한 컴포넌트

### hero-section.html
메인 페이지의 히어로 섹션 (변수 없음)

**사용:**
```html
@@include('components/hero-section.html')
```

---

### page-list.html
페이지 목록 (변수 없음)

**사용:**
```html
@@include('components/page-list.html')
```

---

### card.html
카드 컴포넌트 (변수 지원)

**변수:**
- `title`: 카드 제목
- `description`: 카드 설명
- `link`: 링크 URL
- `buttonText`: 버튼 텍스트

**사용:**
```html
@@include('components/card.html', {
  "title": "제목",
  "description": "설명",
  "link": "/link",
  "buttonText": "버튼"
})
```

---

### button-group.html
버튼 그룹 (변수 지원)

**변수:**
- `primaryLink`: 기본 버튼 링크
- `primaryText`: 기본 버튼 텍스트
- `secondaryLink`: 보조 버튼 링크
- `secondaryText`: 보조 버튼 텍스트

**사용:**
```html
@@include('components/button-group.html', {
  "primaryLink": "#",
  "primaryText": "확인",
  "secondaryLink": "#",
  "secondaryText": "취소"
})
```

## 💡 팁

1. **컴포넌트는 빌드되지 않음**: `components/` 폴더의 파일은 `dest/`에 복사되지 않습니다.
2. **자동 새로고침**: 컴포넌트를 수정하면 Gulp가 자동으로 감지하고 재빌드합니다.
3. **재사용성**: 같은 컴포넌트를 여러 페이지에서 사용할 수 있습니다.
4. **변수 사용**: JSON 형식으로 변수를 전달할 수 있습니다.

## 🚀 작업 흐름

1. `components/`에 새 컴포넌트 HTML 작성
2. 필요하면 `css/style.css`에 스타일 추가
3. 페이지에서 `@@include()`로 컴포넌트 사용
4. Gulp가 자동으로 빌드 → 브라우저 새로고침

